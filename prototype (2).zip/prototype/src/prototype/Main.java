package prototype;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Menu menu = new Menu();
		//NurseView nurseView = new NurseView();
		//DoctorPortal doctorPortal = new DoctorPortal();
		//PatientHistory patientHistory = new PatientHistory();
		//PaientPortal paientPortal = new PaientPortal();
	}

}
