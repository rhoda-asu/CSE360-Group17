package prototype;

public class patientPortal {

}
