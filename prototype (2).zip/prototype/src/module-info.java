/**
 * 
 */
/**
 * @author jahar
 *
 */
module prototype {
	requires java.desktop;
}